package com.dushan.eh.controller;

public class Activity {
	private String activtyName;

	public String getActivtyName() {
		return activtyName;
	}

	public void setActivtyName(String activtyName) {
		this.activtyName = activtyName;
	}
}
