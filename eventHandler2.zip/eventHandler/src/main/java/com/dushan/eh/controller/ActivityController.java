package com.dushan.eh.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;



@Controller
public class ActivityController {
	
	@RequestMapping(value="/greeting")
	public String getWelcomeMessage(Model model) {
		
		model.addAttribute("msg", "Hi Spring You Are Awesome");
		
		return "welcome";
	}
	
	@RequestMapping(value="/addActivity")
	public String addActivity(@ModelAttribute("activities") Activity activity){
		System.out.println(activity.getActivtyName());
		if(activity.getActivtyName()==null){
			return "addActivity";
		}
		else{
			return "redirect:addSubActivity.html";
		}
		
	}

	@RequestMapping(value="/addSubActivity")
	public String addSubActivity(@ModelAttribute("activities") Activity activity){
		System.out.println("sub activity"+activity.getActivtyName());
		return "addActivity";
	}
}
